public class MyObjectTest {
  public static void main(String[] args) {
    MyObject obj = new MyObject();
    obj.helloWorld();
    obj.goodbyeWorld("hello");
  }
}
