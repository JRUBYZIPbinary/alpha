if defined?(Warning) and Warning.respond_to?(:[]=)
  Warning[:deprecated] = true
end
